
//Header files used for serial uart

#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<termios.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

unsigned char temp[256];

void con(int);
void pub(int);

int main()
{
	int uart0_filestream,ssd,ret;
	uart0_filestream = open("/dev/ttyAMA0",O_RDWR );
	printf("HEY\n");
	if(uart0_filestream==-1)
	{
		printf("Error - unable to open uart port\n");
	}

        ssd=socket(AF_INET,SOCK_STREAM,0);
        if(ssd<0) { printf("Error in socket-endpoint creation!\n"); }
        else { printf("Socket created!\n"); }

        struct sockaddr_in saddr;
        saddr.sin_family=AF_INET;
        saddr.sin_port= htons(8080);
        saddr.sin_addr.s_addr=inet_addr("127.0.0.1");
        //bzero(&(saddr.sin_zero),sizeof(saddr.sin_zero));
        ret=connect(ssd,(struct sockaddr*)&saddr,sizeof(saddr));
        if(ret<0){printf("Error!\n");} else {printf("connected!\n");}

	
//	con(ssd);

//Configure the uart

struct termios options;
tcgetattr(uart0_filestream,&options);
options.c_cflag = B9600 | CS8 | CLOCAL | CREAD;
options.c_iflag = IGNPAR;
options.c_oflag = 0;
options.c_lflag = 0;
tcflush(uart0_filestream,TCIFLUSH);
tcsetattr(uart0_filestream, TCSANOW, &options);


//Receiving bytes
	if(uart0_filestream != -1)
	{
		int i=0,rx_length;
		unsigned char rx_buffer;
		con(ssd);
		printf("HOLA\n");
		while(1)
		{
			rx_length=read(uart0_filestream,&rx_buffer,1);
			if(rx_length>0)
			{ 
				temp[i]=rx_buffer;
				if(temp[i++]!='\r')
					continue;
								
				temp[i-1]='\0';
				pub(ssd);
				printf("%s\n",temp);
				i=0;
			}
		}
	}
	close(uart0_filestream);
	return 0;
}

void con(int ssd)
{

	char conn_pack[]={
		  0x10,  //con pack!
		  0x0a,  //len of pack
		  0x00,	
		  0x04,  //length of proto
		  0x4d,	 //M
		  0x51,  //Q
		  0x54,  //T
		  0x54,  //T
		  0x04,  //proto level
		  0x02,  //flags
		  0x00,  //keep alive
		  0x0a,  //keep alive
	};
write(ssd,conn_pack,sizeof(conn_pack));
//printf("connect packet sent!!\n");
}

void pub(int ssd){
int i,j;
char pub_pack[100]={
		0x31,
		0x00,	//length of pack
		0x00,	//msb
		0x0B,	//lsb
		0x43,	//C
		0x44,	//D
		0x41,	//a
		0x43,	//C
		0x2F,	// '/'
		0x41,	//A
		0x53,	//s
		0x41,	//A
		0x50,	//P
		0x2F,	// '/'
		0x41,	//A
		0x00,	//msb
		0x0a,	//lsb
	};
	pub_pack[1]=(char)(strlen(temp)+15);
	pub_pack[17]=0x00;
	pub_pack[18]=(char)(strlen(temp));
	for(i=19,j=0;temp[j]!='\0';i++,j++)
	{
		pub_pack[i]=temp[j];
	}
	pub_pack[i]='\0';

	
	write(ssd,pub_pack,i);
	//send(ssd,pub_pack,sizeof(pub_pack),0);
	//printf("publish done!!\n");
}






















