//#include "stm32f3xx.h"                  // Device header
#include "stm32f303xx.h"

void GPIO_config_test(void);
void uart_init(void);
unsigned char rx_char(void);
void tx_char(unsigned char);
void tx_string(unsigned char *);

void i2c_init();
void i2c_write_byte(unsigned char acc_reg_addr,unsigned char data);
unsigned char i2c_read_byte(unsigned char acc_reg_addr);



int main()
{
	unsigned int x0,x1,x2,x3,x4,x5;
	
	int i,j;
	unsigned char data_x[10],data_y[10],data_z[10];
	i2c_init();
	GPIO_config_test();
	uart_init();
	i2c_write_byte(0x20,0x27);
	while(1)
	{
		x0 = i2c_read_byte(0x28);						// X-AXIS
		x1 = i2c_read_byte(0x29);
		x2 = i2c_read_byte(0x2A);						// Y-AXIS
		x3 = i2c_read_byte(0x2B);
		x4 = i2c_read_byte(0x2C);						// Z-AXIS
		x5 = i2c_read_byte(0x2D);
		
		/*for(i=0;data[i-1]!='z';i++)
		{
		data[i]=rx_char();
		}
		data[i-1]='\0';
		*/
		//data[0]=(unsigned char)((x0 & 0x0f)+48);
		//data[1]=(unsigned char)((((x0 & 0xf0))>>4)+48);
		//data[2]='\0';		
		x1=x1<<8;
		x1=x1^x0;
		
		x3=x3<<8;
		x3=x3^x2;
		
		x5=x5<<8;
		x5=x5^x4;
		
		sprintf(data_x,"%d",x1);
		sprintf(data_y,"%d",x3);
		sprintf(data_z,"%d",x5);
		
		tx_string("X-AXIS : ");
		tx_string(data_x);
		tx_char('\t');
		
		tx_string("Y-AXIS : ");
		tx_string(data_y);
		tx_char('\t');
		
		tx_string("Z-AXIS : ");
		tx_string(data_z);
		tx_char('\t');
		
		tx_char('\n');
		tx_char('\r');
		for(i=0;i<0xfff;i++)
		for(j=0;j<0xff;j++);
	}
	
}

void GPIO_config_test(void)
{
	
	RCC_AHBENR |= (1 << 19);
	GPIOC_MODER |= (1<<9) | (1<<11);
	GPIOC_AFRL |= (7<<16) | (7<<20);
}

void uart_init(void)
{
	int baud;
	RCC_CFGR3|= (3<<0);
	baud= 8000000/9600;
	RCC_APB2ENR |= (1<<14);
	USART1_BRR |= baud;
	USART1_CR1 |=(0<<28) | (0<<12)  | (0<<9) | (1<<2) | (1<<3);
	USART1_CR1 |= (1<<0);
	USART1_CR2 |= (0<<12) | (0<<13);
}

unsigned char rx_char(void)
{ 
while (!(USART1_ISR & (1<<5)));
return (USART1_RDR & 0xFF);
}

void tx_char(unsigned char temp)
{
 while (!(USART1_ISR & (1<<7)));
 USART1_TDR = (temp & 0xFF);
}


void tx_string(unsigned char *ptr)
{
	while(*ptr!='\0')
	{
		tx_char(*ptr++);
	}
}


void i2c_init()
{
	//Enable clocks
	RCC_AHBENR |= BIT18;							//GPIO B clock enabled
	RCC_APB1ENR |= BIT21;							//I2C1 clock enable
	
	//Alternate function enable
	GPIOB_MODER|=(BIT15|BIT13);				//Alternate function for PB6(SCL) and PB7(SDA)
	GPIOB_AFRL |=(BIT26|BIT30);				//SCL and SDA is connected on AF4
	
	//I2C Initialization
	I2C1_CR1 &= ~BIT0;									//disable peripheral 
	I2C1_CR1 |= BIT12;									//analog filter off
	I2C1_CR1 |= BIT8|BIT9|BIT10;				//digital filter enabled 
		
	
	//I2C Timing Setting (10KHz)(Standard Mode)
	I2C1_TIMINGR |= (1<<28) |(4<<20)|(2<<16)|(199<<0)|(195<<8);						//10KHz config according to table
	I2C1_CR2 |= ((0x19)<<1);					//Slave Address of Accelerometer
																		//Fixed since only one slave
	
	I2C1_CR1 |= BIT0;
	
}



void i2c_write_byte(unsigned char acc_reg_addr,unsigned char data) {
    I2C1_CR2 &= ~(BIT10);									
    I2C1_CR2 |= (2 << 16);
    I2C1_CR2 |= BIT13;
		while(I2C1_CR2 & BIT13);
    
		I2C1_TXDR = acc_reg_addr;
    while (!(I2C1_ISR & BIT0));

    I2C1_TXDR = data;
    while (!(I2C1_ISR & BIT0));
    I2C1_CR2 |= BIT14;
    while(I2C1_CR2 & BIT14);
}
	
unsigned char i2c_read_byte(unsigned char acc_reg_addr)
{
		unsigned char data;
		I2C1_CR2 &= ~(BIT10);
		I2C1_CR2 &=~(0xff<<16);
    I2C1_CR2 |= (1 << 16);
		I2C1_CR2 |= BIT13;
		
		while(I2C1_CR2 & BIT13);
    
		I2C1_TXDR = acc_reg_addr;
    while (!(I2C1_ISR & BIT0));

		I2C1_CR2 |= BIT10;									
    I2C1_CR2 |= (1 << 16);
		I2C1_CR2 |= BIT13;
	
		while(I2C1_CR2 & BIT13);
	
		//while(!(I2C1_ISR & BIT2));
		data = I2C1_RXDR;
		
		
		
		I2C1_CR2 |= BIT14;
		//while(I2C1_CR2 & BIT14);
	
		return data;
}	